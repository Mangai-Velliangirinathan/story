//
//  ViewController.swift
//  Dicee-iOS13
//
//  Created by Angela Yu on 11/06/2019.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //allows to reference value
    @IBOutlet weak var diceImageView1: UIImageView!
    
    @IBOutlet weak var diceImageView2: UIImageView!
    
    var leftDiceNumber=1
    var rightDiceNumber=5
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        // Do any additional setup after loading the view.
//
//        //(who.what+value)
//        //value=image.literal
//        diceImageView1.image=#imageLiteral(resourceName: "DiceFive")
//        diceImageView1.alpha=0.5
//        diceImageView1.image=#imageLiteral(resourceName: "DiceTwo")
    }

    @IBAction func rollButtonPressed(_ sender: UIButton) {
        
        print("Button pressed")
        
//        diceImageView1.image=#imageLiteral(resourceName: "DiceFour")
//        diceImageView2.image=#imageLiteral(resourceName: "DiceThree")
        
        
        //array of image literal
//        diceImageView1.image=[#imageLiteral(resourceName: "DiceOne"),#imageLiteral(resourceName: "DiceTwo"),#imageLiteral(resourceName: "DiceThree"),#imageLiteral(resourceName: "DiceFour"),#imageLiteral(resourceName: "DiceFive"),#imageLiteral(resourceName: "DiceSix")][5]
        
        
        let diceImage=[#imageLiteral(resourceName: "DiceOne"),#imageLiteral(resourceName: "DiceTwo"),#imageLiteral(resourceName: "DiceThree"),#imageLiteral(resourceName: "DiceFour"),#imageLiteral(resourceName: "DiceFive"),#imageLiteral(resourceName: "DiceSix")]
//        diceImageView1.image=diceImage[leftDiceNumber]
//        leftDiceNumber=leftDiceNumber+1
//
//        diceImageView2.image=diceImage[rightDiceNumber]
//        rightDiceNumber=rightDiceNumber-1
        
        
        
        diceImageView1.image=diceImage[Int.random(in: 0...5)]
        //does same(randomElement())
        diceImageView2.image=diceImage.randomElement()

    }
    
}

