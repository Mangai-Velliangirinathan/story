//
//  SwiftUIView.swift
//  SwiftUISecProject
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 03/07/20.
//  Copyright © 2020 sample. All rights reserved.
//

import SwiftUI

struct SwiftUIView: View {
    let text:String
    let image:String
    var body: some View {
            RoundedRectangle(cornerRadius: 25)
                .frame(height: 80)
                .foregroundColor(.white)
                .overlay(HStack {
                    Image(systemName: image)
                        .foregroundColor(.orange)
                    Text(text)
                })
                .padding(.all)
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView(text:"hello",image:"phone.fill")
            .previewLayout(.sizeThatFits)
    }
}
