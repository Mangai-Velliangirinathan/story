//
//  ContentView.swift
//  SwiftUISecProject
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 03/07/20.
//  Copyright © 2020 sample. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(red: 0.5, green: 0.5, blue: 0.5,opacity: 0.8)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack {
                Image("SwiftImg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 350.0, height: 200.0)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .overlay(Circle().stroke(Color.white,lineWidth: 3))
                Text("Hello, World!")
                    .font(Font.custom("Pacifico-Regular", size: 40))
                    .bold()
                    .foregroundColor(.white)
                Text("My Second SwiftUI project")
                    .foregroundColor(.white)
                    .font(.system(size: 30))
                Divider()
                SwiftUIView(text: "+44 123 456 789", image: "phone.fill")
                SwiftUIView(text: "angela@email.com", image: "envelope.fill")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//struct infoView: View {
//    let number:String
//    let image:String
//    var body: some View {
//        RoundedRectangle(cornerRadius: 25)
//            .frame(height: 80)
//            .foregroundColor(.white)
//            .overlay(HStack {
//                Image(systemName: image)
//                    .foregroundColor(.orange)
//                Text(number)
//            })
//            .padding(.all)
//    }
//}
