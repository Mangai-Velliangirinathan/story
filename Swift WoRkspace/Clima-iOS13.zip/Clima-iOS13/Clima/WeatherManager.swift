//
//  WeatherManager.swift
//  Clima
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 30/06/20.
//  Copyright © 2020 App Brewery. All rights reserved.
//

import Foundation


protocol WeatherManagerDelegate {
    func didUpdateWeather(weatherModel:WeatherModel)
    func didErrorWeather(error:Error)
}

struct WeatherManager {
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=e72ca729af228beabd5d20e3b7749713&units=metric"
    
    var delegate:WeatherManagerDelegate?
    
    func fetchWeather(cityName:String){
        let urlString="\(weatherURL)&q=\(cityName)"
        print(urlString)
        performRequest(urlString: urlString)
    }
    
    
    func performRequest(urlString: String) {
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    print(error!)
                    self.delegate?.didErrorWeather(error: error!)
                    return
                }
                if let safeData = data {
                    //let dataString=String(data:safeData, encoding: .utf8)
                    //print(dataString)
                    //inside closure call the method with self keyword
                    if let weather=self.parseJSON(weatherData: safeData){
                        self.delegate?.didUpdateWeather(weatherModel: weather)
                    }
                }
            }
            task.resume()
        }
    }
    
    
    func parseJSON(weatherData:Data)->WeatherModel?{
        let decoder=JSONDecoder()
        do{
            let decodedData=try decoder.decode(WeatherData.self, from: weatherData)
            let id = decodedData.weather[0].id
            let temp = decodedData.main.temp
            let name = decodedData.name
            
            let weather = WeatherModel(conditionId: id, cityName: name, temperature: temp)
            print(weather.conditionName)
            return weather
        }
        catch{
            print(error)
            return nil
        }
    }
    
    
    func getWeatherCondition(weatherId:Int)->String{
        switch weatherId {
        case 200...232:
            return "cloud.bolt"
        case 300...321:
            return "cloud.drizzle"
        case 500...531:
            return "cloud.rain"
        case 600...622:
            return "cloud.snow"
        case 701...781:
            return "cloud.fog"
        case 800:
            return "sun.max"
        case 801...804:
            return "cloud.bolt"
        default:
            return "cloud"
        }
    }
        
        
        
        //    func performRequest(weatherUrl:String){
        //        //creatte url
        //        let url=URL(string: weatherURL)
        //        //create session
        //        let session=URLSession(configuration: .default)
        //        //give session a task
        //        let task=session.dataTask(with: url!){
        //           (data,response,error)in
        //            if error != nil{
        //                       print(error!)
        //                       return
        //                   }
        //                   if let safeData = data{
        //                      let dataString=String(data:safeData, encoding: .utf8)
        //                      print(dataString)
        //                   }
        //
        //
        //        }
        //        task.resume()
        //    }
        
        
        
        
        //    func handle(data: Data?, response: URLResponse?, error:Error?){
        //        print("in handlea")
        //        if error != nil{
        //            print(error!)
        //            return
        //        }
        //        if let safeData = data{
        //            let dataString=String(data:safeData, encoding: .utf8)
        //            print(dataString)
        //        }
        //    }
}
