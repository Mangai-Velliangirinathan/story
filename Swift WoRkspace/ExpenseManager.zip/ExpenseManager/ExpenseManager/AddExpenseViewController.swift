//
//  AddExpenseViewController.swift
//  ExpenseManager
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 15/07/20.
//  Copyright © 2020 sample. All rights reserved.
//

import UIKit
import CoreData


class AddExpenseViewController: UIViewController {
    
    private var datePicker:UIDatePicker?
    
    @IBOutlet weak var incomeDetailsView: UIView!
    @IBOutlet weak var dateTxtField: UITextField!
    @IBOutlet weak var salaryDetailStackView: UIStackView!
    
    @IBOutlet weak var otherDetailStackView: UIStackView!
    
    @IBOutlet weak var amtFromSalary: UITextField!
    
    @IBOutlet weak var sourceFromOthers: UITextField!
    @IBOutlet weak var dateFromOthers: UITextField!
    
    @IBOutlet weak var amtFromOthers: UITextField!
    
    let context=(UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var dateToSave:Date?=nil
    
    @IBAction func salaryDetailsBtn(_ sender: UIButton) {
        print("clicked")
        salaryDetailStackView.isHidden=false
        otherDetailStackView.isHidden=true
        
    }
    
    @IBAction func otherDetailsBtn(_ sender: UIButton) {
        print("clickedo")
        
        salaryDetailStackView.isHidden=true
        otherDetailStackView.isHidden=false
    }
    
    @IBAction func incomeDetailsBtn(_ sender: UIButton) {
    }
    
    @IBAction func expenseDetailsBtn(_ sender: UIButton) {
        incomeDetailsView.isHidden=true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(FileManager.default.urls(for: .documentDirectory, in: .userDomainMask))
        salaryDetailStackView.isHidden=true
        otherDetailStackView.isHidden=true
        
        datePicker=UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action: #selector(AddExpenseViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(AddExpenseViewController.viewTapped(gestureRecognizer:)))
        dateTxtField.inputView=datePicker
        
        loadItems()
        
    }
    
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer){
    
    }
    
    @objc func dateChanged(datePicker:UIDatePicker){
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/mm/yyyy"
        dateTxtField.text=formatter.string(from: datePicker.date)
        let dateSaved:String=dateTxtField!.text ?? "00/00/0000"
        dateToSave = formatter.date(from:dateSaved)
        view.endEditing(true)
    }
    
    @IBAction func saveBtnPressed(_ sender: UIButton) {
        print("inside save butn")
        let newDataToSave = ExpenseManagerEntity(context:self.context)
        newDataToSave.amount=Double(amtFromSalary.text!) ?? 0.00
        newDataToSave.category="Income"
        newDataToSave.dataInfo="Salary"
        newDataToSave.date=dateToSave
        saveItems()
        
    }
    
    func saveItems(){
        do {
            try context.save()
        } catch {
            print("Error saving context \(error)")
        }
    }
    
    func loadItems(){
        let request: NSFetchRequest<ExpenseManagerEntity> = ExpenseManagerEntity.fetchRequest()
        do{
            let daata=try context.fetch(request)
            print("dattta ",daata.count)
        }catch{
            print("Error while fetching")
        }
    }
    
    
    
}
