//
//  DailyExpenseViewController.swift
//  ExpenseManager
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 17/07/20.
//  Copyright © 2020 sample. All rights reserved.
//

import UIKit

class DailyExpenseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("daily expense view controller")

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
