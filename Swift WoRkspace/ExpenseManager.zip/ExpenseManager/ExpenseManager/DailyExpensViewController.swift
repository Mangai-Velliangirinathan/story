//
//  DailyExpensViewController.swift
//  ExpenseManager
//
//  Created by Mangaiyarkkarasi_Velliangirinathan on 20/07/20.
//  Copyright © 2020 sample. All rights reserved.
//

import UIKit
import CoreData

class DailyExpensViewController: UITableViewController {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var itemArray=[ExpenseManagerEntity]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("from DailyExpenses")
        loadItemsFromDb()
        // Do any additional setup after loading the view.
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0;//Choose your custom row height
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell", for: indexPath) as! CustomTableCellTableViewCell
        
        let item = itemArray[indexPath.row]
        
        
        cell.sourceLabel.text=item.source
        cell.amountLabel.text=String(item.amount)
//        cell.dateLabel.text=(item.date)
        //cell.textLabel?.text = String(item.amount)
        
        //Ternary operator ==>
        // value = condition ? valueIfTrue : valueIfFalse
        
        //    cell.accessoryType = item.done ? .checkmark : .none
        
        return cell
    }
    
    func loadItemsFromDb(){
        let request: NSFetchRequest<ExpenseManagerEntity> = ExpenseManagerEntity.fetchRequest()
        do{
            itemArray=try context.fetch(request)
            print("****",itemArray)
            if itemArray.count>0{
                print(itemArray[0].amount,"from loadItemsDB")
            }
        }
        catch{
            print("Error in fetching")
        }
    }
    
}
