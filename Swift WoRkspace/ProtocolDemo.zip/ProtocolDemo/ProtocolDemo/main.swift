class Bird{
    func fly(){
        print("Birds can fly")
    }
    
    func canLayEggs(){
        print("Female birds can lay eggs")
    }
}

class Eagle:Bird{
    func soar(){
        print("Birds soar")
    }
}

class Penguin:Bird{
    func swim(){
        print("Penguin can swim")
    }
}


struct FlyingMuseum{
    func flyingDemo(flyingObject:Bird){
        flyingObject.fly()
    }
}

let mEagle = Eagle()
mEagle.fly()
mEagle.canLayEggs()


let museum=FlyingMuseum()
museum.flyingDemo(flyingObject: mEagle)

