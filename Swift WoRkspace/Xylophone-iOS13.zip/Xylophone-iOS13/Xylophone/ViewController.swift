//
//  ViewController.swift
//  Xylophone
//
//  Created by Angela Yu on 28/06/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
//AudioVisual Foundation
import AVFoundation

class ViewController: UIViewController {

    var player: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func keyPressedC(_ sender: UIButton) {
        //print()
        
        //Reduces the sender's (the button that got pressed) opacity to half.
        sender.alpha = 0.5

        //Code should execute after 0.2 second delay.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            //Bring's sender's opacity back up to fully opaque.
            sender.alpha = 1.0
        }
        playSound(soundName: sender.currentTitle!)
    }
    
    
    func playSound(soundName: String) {
        
//        //A representation of the code and resources stored in a bundle directory on disk.
//        //using a bundle object, you can access a bundle's resources without knowing the structure of the bundle.
//    guard let url = Bundle.main.url(forResource: "C", withExtension: "wav") else { return }
//
//    do {
//
//        //An object that communicates to the system how you intend to use audio in your app.
//        //AVAudioSession.sharedInstance() returns audio session instance
//
//        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
//        try AVAudioSession.sharedInstance().setActive(true)
//
//        /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
//        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
//
//        /* iOS 10 and earlier require the following line:
//        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
//
//        guard let player = player else { return }
//
//        player.play()
//
//    } catch let error {
//        print(error.localizedDescription)
//    }
    
        
        
        
        let url = Bundle.main.url(forResource: soundName, withExtension:"wav")
        player=try! AVAudioPlayer(contentsOf: url!)
        player?.play()
        

    }
    

}

